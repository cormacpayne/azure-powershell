﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Azure.Commands.$ext_projectname$.Test.ScenarioTests
{
    class DELETE_THIS_FILE
    {
    }
}
