﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Azure.Commands.$ext_projectname$.Common
{
    class DELETE_THIS_FILE
    {
    }
}
